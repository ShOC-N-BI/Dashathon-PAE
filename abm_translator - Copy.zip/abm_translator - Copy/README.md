# abm_translator - Copy

