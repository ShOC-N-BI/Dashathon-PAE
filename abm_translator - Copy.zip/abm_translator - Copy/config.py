from dotenv import load_dotenv
import os

# Load values from .env file at project root
load_dotenv()

# ---------------------------------------------------------------------------
# IRC
# ---------------------------------------------------------------------------
IRC_SERVER  = os.getenv("IRC_SERVER",  "10.5.185.72")
IRC_PORT    = int(os.getenv("IRC_PORT", "6667"))
IRC_CHANNEL = os.getenv("IRC_CHANNEL", "#app_dev")

# ---------------------------------------------------------------------------
# LM Studio
# ---------------------------------------------------------------------------
LM_STUDIO_URL = os.getenv("LM_STUDIO_URL", "http://10.5.185.55:4334/v1/chat/completions")
LM_MODEL      = os.getenv("LM_MODEL",      "google/gemma-4-E4B")
LM_TIMEOUT    = int(os.getenv("LM_TIMEOUT", "20"))

# # 1. Load the .env file
# load_dotenv() 

# # 2. Pull the variables (names must match exactly what's in your .env)
# LM_API_KEY    = os.getenv("NANOGPT_API_KEY") # Assuming your .env has LM_API_KEY=your_key
# LM_STUDIO_URL = os.getenv("LM_STUDIO_URL", "https://nano-gpt.com/api/v1/chat/completions")
# LM_MODEL      = os.getenv("LM_MODEL", "anthropic/claude-opus-4.7")
# LM_TIMEOUT    = int(os.getenv("LM_TIMEOUT", "30"))

# # 3. Example of how to use it in your headers
# headers = {
#     "Authorization": f"Bearer {LM_API_KEY}",
#     "Content-Type": "application/json"
# }
# ---------------------------------------------------------------------------
# Battle API
# ---------------------------------------------------------------------------
BATTLE_API_URL = os.getenv("BATTLE_API_URL", "")

# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------
DB_HOST     = os.getenv("DB_HOST",     "10.5.185.53")
DB_NAME     = os.getenv("DB_NAME",     "shooca_db")
DB_USER     = os.getenv("DB_USER",     "shooca")
DB_PASSWORD = os.getenv("DB_PASSWORD", "shooca222")
DB_PORT     = int(os.getenv("DB_PORT", "5432"))