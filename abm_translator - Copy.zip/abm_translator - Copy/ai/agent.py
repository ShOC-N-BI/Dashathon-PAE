import csv
import json
import re
import requests
from pathlib import Path

# ---------------------------------------------------------------------------
# PATHS  — CSVs live in data/ at the project root
# ---------------------------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent.parent
CSV_TACTICAL_CHAT = BASE_DIR / "data" / "standard_tactical_chat_abbreviations.csv"
CSV_BREVITY_CODES = BASE_DIR / "data" / "brevity_codes_2025_standard.csv"
CSV_GLOSSARY      = BASE_DIR / "data" / "tactical_glossary_abbreviations.csv"

# ---------------------------------------------------------------------------
# BATTLE DICTIONARY  — verb pool the AI must pick from
# ---------------------------------------------------------------------------

BATTLE_DICTIONARY = {
    "ATTACK": [
        "ATTACK", "INTERCEPT", "AMBUSH", "ASSAIL", "ASSAULT", "STRIKE", "HIT", "RAID", "INVADE",
        "ADVANCE", "SHOOT", "SUPPRESS", "DISABLE", "SMACK", "DESTROY", "KILL", "NULLIFY", "TERMINATE",
        "VANISH", "RETALIATE", "BRACE FOR IMPACT", "PREPARE", "FORTIFY", "ENGAGE", "COVER",
        "DOUBLE TAP", "CUT OFF", "BANZAI", "TARGET", "HOSTILE", "ENEMY",
    ],
    "INVESTIGATE": [
        "INVESTIGATE", "CONSIDER", "EXAMINE", "EXPLORE", "INSPECT", "INTERROGATE", "PROBE",
        "QUESTION", "REVIEW", "SEARCH", "STUDY", "INQUIRE", "RESEARCH", "FADED", "FADE", "SHADOW",
        "COMMUNICATE", "BROADCAST", "CONTACT", "CONVEY", "CORRESPOND", "DISCLOSE", "REACH OUT",
        "ASLEEP", "AWAKE", "AUTHENTICATE", "PASS ON", "TELL", "TRANSFER", "TRANSMIT", "DISCOVER",
        "RELAY", "REPORT", "RESPOND", "CAPTURE", "IMAGE", "IDENTIFY", "RECOGNIZE", "SPOT", "TRACK",
        "LOCATE", "PINPOINT", "DETECT", "FIND", "UNCOVER", "REVEAL", "EXPOSE", "UNRAVEL", "COLLECT",
        "MONITOR", "SEEN", "WITNESS", "OBSERVE", "WATCH", "VIEW", "PERCEIVE", "LISTEN", "BAD MAP",
        "BEAM RIDER", "CAP", "CAPPING", "CHECK", "DELOUSE", "FEELER", "CATALOG", "ID", "MAP", "MARK",
        "STROKE", "BOLO", "CK", "CHECKMATE", "CONFIRM", "CONFIRMING", "CONFIRMATORY",
    ],
    "DEGRADE": [
        "DEGRADE", "DECEIVE", "DENY", "DELAY", "DIMINISH", "REDUCE", "WEAKEN", "IMPAIR",
        "DETERIORATE", "COUNTER", "HINDER", "COUNTERACT", "OPPOSE", "JAM", "BLOCK", "BIND",
        "CONGEST", "HACK", "HARASS", "HASSLE", "INTIMIDATE", "TORMENT", "DISTURB", "PSYOP",
        "PROPAGANDA", "BUZZER ON",
    ],
    "RESCUE": [
        "RESCUE", "REPAIR", "SAVE", "RECOVER", "RETRIEVE", "FREE", "LIBERATE", "RELEASE",
        "PROTECT", "SHIELD", "EVADE", "AVOID", "CIRCUMVENT", "CONCEAL", "ELUDE", "ESCAPE",
        "FEND OFF", "FLEE", "HIDE", "AVALANCHE", "FLASHLIGHT",
    ],
}

# Flat list used for prompt injection and response validation
ALL_VERBS: list[str] = [v for verbs in BATTLE_DICTIONARY.values() for v in verbs]

# ---------------------------------------------------------------------------
# CSV LOADER  — loaded once at import time, reused on every call
# ---------------------------------------------------------------------------

def _load_csv_as_text(filepath: Path) -> str:
    """Read a CSV and return it as a compact pipe-delimited string block."""
    try:
        with open(filepath, newline="", encoding="utf-8") as f:
            rows = [" | ".join(cell.strip() for cell in row) for row in csv.reader(f)]
        return "\n".join(rows)
    except FileNotFoundError:
        print(f"⚠️  CSV not found: {filepath}")
        return f"[CSV NOT FOUND: {filepath.name}]"


def _load_all_csvs() -> str:
    """Combine all three reference CSVs into one labelled block for the prompt."""
    return (
        "=== TACTICAL CHAT ABBREVIATIONS ===\n" + _load_csv_as_text(CSV_TACTICAL_CHAT) + "\n\n"
        "=== BREVITY CODES ===\n"               + _load_csv_as_text(CSV_BREVITY_CODES) + "\n\n"
        "=== TACTICAL GLOSSARY ===\n"           + _load_csv_as_text(CSV_GLOSSARY)
    )


# Loaded once when the module is first imported
CSV_CONTEXT: str = _load_all_csvs()

# ---------------------------------------------------------------------------
# SYSTEM PROMPT
# ---------------------------------------------------------------------------

def _build_system_prompt() -> str:
    verb_list = ", ".join(ALL_VERBS)
    return f"""You are a tactical AI analyst embedded in a real-time battlefield communications pipeline.

Your sole job is to read an incoming tactical chat message and assign exactly THREE effect operator verbs
to the three battle effect slots (e01, e02, e03) in order of tactical priority.

RULES:
1. You MUST choose each verb exclusively from the APPROVED VERB LIST below. No improvisation.
2. Each verb must belong to a DIFFERENT category (ATTACK, INVESTIGATE, DEGRADE, RESCUE) when possible.
   If the message strongly implies only one or two categories, you may repeat a category — but never
   use the exact same verb twice.
3. Rank your choices: e01 = highest priority action, e02 = secondary, e03 = tertiary.
4. Use the three reference tables (Tactical Chat Abbreviations, Brevity Codes, Tactical Glossary)
   to decode any abbreviations or brevity codes in the message before making your decision.
5. Return ONLY valid JSON — no explanation, no markdown, no preamble.

APPROVED VERB LIST:
{verb_list}

OUTPUT FORMAT (strict JSON, nothing else):
{{
  "e01_effectOperator": "<VERB>",
  "e02_effectOperator": "<VERB>",
  "e03_effectOperator": "<VERB>"
}}

REFERENCE TABLES:
{CSV_CONTEXT}
"""

# ---------------------------------------------------------------------------
# PUBLIC INTERFACE
# ---------------------------------------------------------------------------

def get_verbs(msg_content: str, lm_url: str, lm_model: str, timeout: int = 20) -> tuple[str, str, str]:
    """
    Send a tactical message to LM Studio and return three effect operator verbs.

    Parameters
    ----------
    msg_content : The raw (already filtered) tactical message text.
    lm_url      : Full URL to the LM Studio completions endpoint.
    lm_model    : Model identifier string (e.g. "google/gemma-4-E4B").
    timeout     : Request timeout in seconds.

    Returns
    -------
    A tuple of (e01_verb, e02_verb, e03_verb).
    Falls back to ("PENDING", "PENDING", "PENDING") on any failure.
    """
    payload = {
        "model": lm_model,
        "messages": [
            {"role": "system", "content": _build_system_prompt()},
            {"role": "user",   "content": f"TACTICAL MESSAGE: {msg_content}"},
        ],
        "temperature": 0.2,
        "max_tokens": 120,
        "stream": False,
    }

    try:
        response = requests.post(lm_url, json=payload, timeout=timeout)
        response.raise_for_status()

        raw = response.json()["choices"][0]["message"]["content"].strip()

        # Strip markdown code fences if the model wraps its output
        raw = re.sub(r"^```[a-z]*\n?", "", raw)
        raw = re.sub(r"\n?```$", "", raw).strip()

        parsed = json.loads(raw)

        def _validate(v: str) -> str:
            v = v.upper()
            return v if v in ALL_VERBS else "PENDING"

        v1 = _validate(parsed.get("e01_effectOperator", "PENDING"))
        v2 = _validate(parsed.get("e02_effectOperator", "PENDING"))
        v3 = _validate(parsed.get("e03_effectOperator", "PENDING"))

        print(f"🤖  AI verbs → e01:[{v1}]  e02:[{v2}]  e03:[{v3}]")
        return v1, v2, v3

    except requests.exceptions.Timeout:
        print(f"⚠️  LM Studio timed out after {timeout}s — using PENDING.")
    except requests.exceptions.ConnectionError:
        print(f"⚠️  Cannot reach LM Studio at {lm_url} — using PENDING.")
    except (requests.exceptions.HTTPError, ValueError, KeyError, json.JSONDecodeError) as e:
        print(f"⚠️  LM Studio error ({type(e).__name__}: {e}) — using PENDING.")

    return "PENDING", "PENDING", "PENDING"