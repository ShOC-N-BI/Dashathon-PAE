import uuid
from datetime import datetime, timezone


def build(
    msg_content: str,
    username: str,
    verb1: str,
    verb2: str,
    verb3: str,
) -> list:
    """
    Assemble the complete Battle JSON record from a filtered message and AI verbs.

    This is a pure function — no I/O, no network calls, no side effects.
    All inputs come in, one JSON structure comes out.

    Parameters
    ----------
    msg_content : The raw filtered message text from IRC.
    username    : The IRC username of the sender.
    verb1       : e01 effect operator (highest priority).
    verb2       : e02 effect operator (secondary).
    verb3       : e03 effect operator (tertiary).

    Returns
    -------
    A list containing one battle JSON dict, matching the PAE schema.
    """
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f+00:00")
    track_id = uuid.uuid4().hex[:6]

    return [{
        "id": username,
        "requestId": f"track-{track_id}",
        "label": None,
        "description": None,
        "gbcId": None,
        "entitiesOfInterest": [],
        "battleEntity": [],
        "battleEffects": [
            {
                "id": "pae-002-e01",
                "effectOperator": verb1,
                "description": None,
                "timeWindow": None,
                "stateHypothesis": None,
                "opsLimits": [{"description": None, "battleEntity": None, "stateHypothesis": None}],
                "goalContributions": [{"battleGoal": None, "effect": None}],
                "recommended": True,
                "ranking": 1,
            },
            {
                "id": "pae-002-e02",
                "effectOperator": verb2,
                "description": None,
                "timeWindow": None,
                "stateHypothesis": None,
                "opsLimits": [{"description": None, "battleEntity": None, "stateHypothesis": None}],
                "goalContributions": [{"battleGoal": None, "effect": None}],
                "recommended": False,
                "ranking": 2,
            },
            {
                "id": "pae-002-e03",
                "effectOperator": verb3,
                "description": None,
                "timeWindow": None,
                "stateHypothesis": None,
                "opsLimits": [{"description": None, "battleEntity": None, "stateHypothesis": None}],
                "goalContributions": [{"battleGoal": None, "effect": None}],
                "recommended": False,
                "ranking": 3,
            },
        ],
        "chat": [
            msg_content,
            "PAE generated for pre-emptive and defensive options.",
        ],
        "isDone": False,
        "originator": username,
        "lastUpdated": now,
    }]