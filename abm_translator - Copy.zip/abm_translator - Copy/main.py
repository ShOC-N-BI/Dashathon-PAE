import config
from ai.agent import get_verbs
from irc.listener import start
from output import log_writer, api_push
from pipeline.builder import build
from pipeline.filter import is_clean

from datetime import datetime
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.table import Table

# ---------------------------------------------------------------------------
# DASHBOARD
# ---------------------------------------------------------------------------

console = Console()


def make_dashboard(
    last_msg: str  = None,
    last_user: str = None,
    verbs: tuple   = None,
    status: str    = "LISTENING",
) -> Table:
    """Render the Rich terminal dashboard table."""
    table = Table(
        title="📡  ABM Tactical Translator — Live Monitor",
        expand=True,
        show_lines=True,
    )
    table.add_column("Timestamp",                  style="cyan",        no_wrap=True)
    table.add_column("Origin",                     style="magenta")
    table.add_column("Raw Tactical Message",       style="green")
    table.add_column("AI Assessment (E01|E02|E03)",style="bold yellow")
    table.add_column("Status",                     style="bold blue")

    if last_msg:
        verb_str = f"{verbs[0]} | {verbs[1]} | {verbs[2]}" if verbs else "—"
        table.add_row(
            datetime.now().strftime("%H:%M:%S"),
            last_user or "Unknown",
            last_msg,
            verb_str,
            status,
        )
    else:
        table.add_row("—", "—", "Waiting for IRC traffic...", "—", "LISTENING")

    return table


# ---------------------------------------------------------------------------
# MESSAGE HANDLER
# ---------------------------------------------------------------------------

def handle_message(live: Live, username: str, message: str) -> None:
    """
    Called by irc.listener for every incoming message.
    Runs the full pipeline: filter → AI → build → output.
    """
    if not is_clean(message):
        live.update(make_dashboard(message, username, None, "FILTERED (NOISE)"))
        return

    # Show thinking state while waiting on LM Studio
    live.update(make_dashboard(message, username, None, "THINKING..."))

    v1, v2, v3 = get_verbs(
        msg_content=message,
        lm_url=config.LM_STUDIO_URL,
        lm_model=config.LM_MODEL,
        timeout=config.LM_TIMEOUT,
    )

    tactical_json = build(
        msg_content=message,
        username=username,
        verb1=v1,
        verb2=v2,
        verb3=v3,
    )

    # Write to log file
    log_writer.write(tactical_json)

    # Push to Battle API if a URL is configured
    if config.BATTLE_API_URL:
        api_push.push(tactical_json, api_url=config.BATTLE_API_URL)

    live.update(make_dashboard(message, username, (v1, v2, v3), "COMPLETED"))


# ---------------------------------------------------------------------------
# ENTRY POINT
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    console.print(
        Panel(
            f"[bold cyan]Server:[/bold cyan]  {config.IRC_SERVER}:{config.IRC_PORT}\n"
            f"[bold cyan]Channel:[/bold cyan] {config.IRC_CHANNEL}\n"
            f"[bold cyan]Model:[/bold cyan]   {config.LM_MODEL}\n"
            f"[bold cyan]API:[/bold cyan]     {config.BATTLE_API_URL or 'not configured — log only'}",
            title="ABM Tactical Translator",
            border_style="cyan",
        )
    )

    with Live(make_dashboard(), refresh_per_second=4, console=console) as live:
        try:
            start(
                server=config.IRC_SERVER,
                port=config.IRC_PORT,
                channel=config.IRC_CHANNEL,
                on_message=lambda user, msg: handle_message(live, user, msg),
            )
        except KeyboardInterrupt:
            console.print("\n[bold yellow]Shutting down.[/bold yellow]")
        except Exception as e:
            console.print(Panel(f"[bold red]CRITICAL ERROR:[/bold red] {e}"))